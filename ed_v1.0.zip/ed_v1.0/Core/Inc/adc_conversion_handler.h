#ifndef ADC_CONVERSION_HANDLER_H
#define ADC_CONVERSION_HANDLER_H

int sumit(int a, int b);

#endif
