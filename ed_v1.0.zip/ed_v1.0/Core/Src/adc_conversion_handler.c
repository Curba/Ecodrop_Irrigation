#include "adc_conversion_handler.h"

int sumit(int a, int b){
	return a+b;
}
